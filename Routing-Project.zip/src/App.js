import { BrowserRouter,Routes,Route } from "react-router-dom";
import Header from "./Components/Header";
import Dashboard from "./Components/Dashboard";
import Footer from "./Components/Footer";
import About from "./Components/About";
import Course from "./Components/Course";
import Team from "./Components/Team";
function App() {
  return (
<BrowserRouter>
<Routes>
  <Route index path="/" element={<><Header/> <Dashboard/> <Footer/></>}></Route> 
  <Route path="/About" element={<><Header/> <About/> <Footer/></>}></Route> 
  <Route path="/Course" element={<><Header/> <Course/> <Footer/></>}></Route> 
  <Route path="/Team" element={<><Header/> <Team/> <Footer/></>}></Route> 
</Routes>
</BrowserRouter>
  );
}

export default App;
